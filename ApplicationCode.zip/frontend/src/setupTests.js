import "@testing-library/jest-dom";
//import { server } from "./test/server";

// enable API mocking in test runs using the same request handlers
// as for the client-side mocking.
// beforeAll(() => server.listen());
// afterEach(() => server.resetHandlers());
// afterAll(() => server.close());
